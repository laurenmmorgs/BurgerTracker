package com.laurenmorgan.burgertracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BurgerTracker1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
