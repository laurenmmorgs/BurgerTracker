package com.laurenmorgan.burgertracker.controllers;

public class BurgersApi {

}
